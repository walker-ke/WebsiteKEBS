<?php
//Step1
 $conn = mysqli_connect('localhost','root','root','kebsNew')
 or die('Error connecting to MySQL server.');
?>